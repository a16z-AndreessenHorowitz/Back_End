const PATH_ADMIN="/admin";
module.exports={
prefixAdmin:PATH_ADMIN
};